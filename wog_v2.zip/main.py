from app import welcome, start_play
welcome()
start_play()
